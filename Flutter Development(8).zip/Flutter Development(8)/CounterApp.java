import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CounterApp {
    private int counter = 0;
    private JLabel label;

    public CounterApp() {
        JFrame frame = new JFrame("Simple Counter App");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        label = new JLabel("Counter: 0", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 24));

        JButton button = new JButton("Increment");
        button.setFont(new Font("Arial", Font.PLAIN, 18));
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                counter++;
                label.setText("Counter: " + counter);
            }
        });

        frame.setLayout(new BorderLayout());
        frame.add(label, BorderLayout.CENTER);
        frame.add(button, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new CounterApp();
    }
}
