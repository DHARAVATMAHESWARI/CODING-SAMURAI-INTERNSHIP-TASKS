import javax.swing.*;
import java.awt.*;

public class WeatherApp {

    public static void main(String[] args) {
        // Create frame
        JFrame frame = new JFrame("Static Weather App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Create panel with vertical layout
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(200, 230, 255));

        // Add spacing
        panel.add(Box.createVerticalStrut(20));

        // Weather icon
        JLabel iconLabel = new JLabel("\u2600"); // ☀️ Unicode sun symbol
        iconLabel.setFont(new Font("Arial", Font.PLAIN, 64));
        iconLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(iconLabel);

        // City name
        JLabel cityLabel = new JLabel("Telangana");
        cityLabel.setFont(new Font("Arial", Font.BOLD, 28));
        cityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(cityLabel);

        // Temperature
        JLabel tempLabel = new JLabel("Temperature: 27°C");
        tempLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        tempLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(tempLabel);

        // Humidity
        JLabel humidityLabel = new JLabel("Humidity: 75%");
        humidityLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        humidityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(humidityLabel);

        // Condition
        JLabel conditionLabel = new JLabel("Condition: raining");
        conditionLabel.setFont(new Font("Arial", Font.PLAIN, 20));
        conditionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(conditionLabel);

        // Add panel to frame and display
        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }
}
