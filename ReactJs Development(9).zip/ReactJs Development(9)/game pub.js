const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player = {
    x: 400,
    y: 300,
    size: 20,
    speed: 5
};

let bullets = [];
let enemies = [];

document.addEventListener("keydown", movePlayer);
document.addEventListener("keydown", shootBullet);

function movePlayer(e) {
    if (e.key === "w") player.y -= player.speed;
    if (e.key === "s") player.y += player.speed;
    if (e.key === "a") player.x -= player.speed;
    if (e.key === "d") player.x += player.speed;
}

function shootBullet(e) {
    if (e.code === "Space") {
        bullets.push({ x: player.x, y: player.y, size: 5, speed: 7 });
    }
}

function spawnEnemy() {
    const side = Math.random() < 0.5 ? 0 : canvas.width;
    enemies.push({
        x: side,
        y: Math.random() * canvas.height,
        size: 20,
        speed: 2
    });
}

function updateGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw player
    ctx.fillStyle = "lime";
    ctx.fillRect(player.x, player.y, player.size, player.size);

    // Move and draw bullets
    for (let i = bullets.length - 1; i >= 0; i--) {
        bullets[i].x += bullets[i].speed;
        ctx.fillStyle = "yellow";
        ctx.fillRect(bullets[i].x, bullets[i].y, bullets[i].size, bullets[i].size);

        // Remove off-screen bullets
        if (bullets[i].x > canvas.width) bullets.splice(i, 1);
    }

    // Move and draw enemies
    for (let i = enemies.length - 1; i >= 0; i--) {
        const dx = player.x - enemies[i].x;
        const dy = player.y - enemies[i].y;
        const dist = Math.hypot(dx, dy);
        enemies[i].x += (dx / dist) * enemies[i].speed;
        enemies[i].y += (dy / dist) * enemies[i].speed;

        ctx.fillStyle = "red";
        ctx.fillRect(enemies[i].x, enemies[i].y, enemies[i].size, enemies[i].size);

        // Collision detection
        for (let j = bullets.length - 1; j >= 0; j--) {
            if (Math.abs(bullets[j].x - enemies[i].x) < 20 && Math.abs(bullets[j].y - enemies[i].y) < 20) {
                enemies.splice(i, 1);
                bullets.splice(j, 1);
                break;
            }
        }
    }

    requestAnimationFrame(updateGame);
}

setInterval(spawnEnemy, 1500);
updateGame();
