import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;

public class ToDoListApp {
    private JFrame frame;
    private DefaultListModel<String> taskListModel;
    private JList<String> taskList;
    private JTextField taskInput;
    private ArrayList<String> tasks;
    private final String FILE_NAME = "tasks.txt";

    public ToDoListApp() {
        tasks = new ArrayList<>();
        loadTasks();

        frame = new JFrame("To-Do List App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 500);

        taskListModel = new DefaultListModel<>();
        for (String task : tasks) {
            taskListModel.addElement(task);
        }

        taskList = new JList<>(taskListModel);
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        taskList.setFont(new Font("Arial", Font.PLAIN, 16));

        JScrollPane scrollPane = new JScrollPane(taskList);

        taskInput = new JTextField();
        JButton addButton = new JButton("Add Task");
        JButton deleteButton = new JButton("Delete Selected");
        JButton markCompleteButton = new JButton("Mark Complete");

        addButton.addActionListener(e -> addTask());
        deleteButton.addActionListener(e -> deleteTask());
        markCompleteButton.addActionListener(e -> markTaskComplete());

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(1, 3));
        panel.add(addButton);
        panel.add(markCompleteButton);
        panel.add(deleteButton);

        frame.getContentPane().add(taskInput, BorderLayout.NORTH);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        frame.getContentPane().add(panel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private void addTask() {
        String task = taskInput.getText().trim();
        if (!task.isEmpty()) {
            taskListModel.addElement(task);
            tasks.add(task);
            taskInput.setText("");
            saveTasks();
        }
    }

    private void deleteTask() {
        int selected = taskList.getSelectedIndex();
        if (selected != -1) {
            tasks.remove(selected);
            taskListModel.remove(selected);
            saveTasks();
        }
    }

    private void markTaskComplete() {
        int selected = taskList.getSelectedIndex();
        if (selected != -1) {
            String task = tasks.get(selected);
            if (!task.startsWith("[✓] ")) {
                task = "[✓] " + task;
                tasks.set(selected, task);
                taskListModel.set(selected, task);
                saveTasks();
            }
        }
    }

    private void saveTasks() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (String task : tasks) {
                writer.write(task);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving tasks: " + e.getMessage());
        }
    }

    private void loadTasks() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                tasks.add(line);
            }
        } catch (IOException e) {
            // File might not exist, ignore
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ToDoListApp::new);
    }
}
